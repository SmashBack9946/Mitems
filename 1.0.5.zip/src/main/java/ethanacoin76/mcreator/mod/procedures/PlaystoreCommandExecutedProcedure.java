package ethanacoin76.mcreator.mod.procedures;

import net.minecraftforge.fml.server.ServerLifecycleHooks;

import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.Util;
import net.minecraft.server.MinecraftServer;

import java.util.Map;

import ethanacoin76.mcreator.mod.MitemsModElements;
import ethanacoin76.mcreator.mod.MitemsMod;

@MitemsModElements.ModElement.Tag
public class PlaystoreCommandExecutedProcedure extends MitemsModElements.ModElement {
	public PlaystoreCommandExecutedProcedure(MitemsModElements instance) {
		super(instance, 56);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MitemsMod.LOGGER.warn("Failed to load dependency world for procedure PlaystoreCommandExecuted!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		if (!world.isRemote()) {
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().func_232641_a_(
						new StringTextComponent("download my apps at https://play.google.com/store/apps/developer?id=EthanAucoin76"), ChatType.SYSTEM,
						Util.DUMMY_UUID);
		}
	}
}
