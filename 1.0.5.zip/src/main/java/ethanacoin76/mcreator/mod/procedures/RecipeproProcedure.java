package ethanacoin76.mcreator.mod.procedures;

import java.util.Map;

import ethanacoin76.mcreator.mod.MitemsModElements;

@MitemsModElements.ModElement.Tag
public class RecipeproProcedure extends MitemsModElements.ModElement {
	public RecipeproProcedure(MitemsModElements instance) {
		super(instance, 27);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
