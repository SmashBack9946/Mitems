package ethanacoin76.mcreator.mod.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.Map;

import ethanacoin76.mcreator.mod.MitemsModElements;
import ethanacoin76.mcreator.mod.MitemsMod;

@MitemsModElements.ModElement.Tag
public class PotionofcopperyPotionExpiresProcedure extends MitemsModElements.ModElement {
	public PotionofcopperyPotionExpiresProcedure(MitemsModElements instance) {
		super(instance, 57);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MitemsMod.LOGGER.warn("Failed to load dependency entity for procedure PotionofcopperyPotionExpires!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity) {
			((LivingEntity) entity).attackEntityFrom(new DamageSource("copperkill").setDamageBypassesArmor(), (float) 5);
		}
	}
}
