package ethanacoin76.mcreator.mod.procedures;

import net.minecraftforge.fml.server.ServerLifecycleHooks;

import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.Util;
import net.minecraft.server.MinecraftServer;

import java.util.Map;

import ethanacoin76.mcreator.mod.MitemsModElements;
import ethanacoin76.mcreator.mod.MitemsMod;

@MitemsModElements.ModElement.Tag
public class DiscordCommandExecutedProcedure extends MitemsModElements.ModElement {
	public DiscordCommandExecutedProcedure(MitemsModElements instance) {
		super(instance, 55);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MitemsMod.LOGGER.warn("Failed to load dependency world for procedure DiscordCommandExecuted!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		if (!world.isRemote()) {
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().func_232641_a_(new StringTextComponent("join discord server discord.gg/ethana76"), ChatType.SYSTEM,
						Util.DUMMY_UUID);
		}
	}
}
