
package ethanacoin76.mcreator.mod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import ethanacoin76.mcreator.mod.item.OverpoweredshardItem;
import ethanacoin76.mcreator.mod.MitemsModElements;

@MitemsModElements.ModElement.Tag
public class MItemsmiscItemGroup extends MitemsModElements.ModElement {
	public MItemsmiscItemGroup(MitemsModElements instance) {
		super(instance, 44);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabm_itemsmisc") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(OverpoweredshardItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
