
package ethanacoin76.mcreator.mod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import ethanacoin76.mcreator.mod.itemgroup.MItemsmiscItemGroup;
import ethanacoin76.mcreator.mod.MitemsModElements;

@MitemsModElements.ModElement.Tag
public class OverpoweredswordItem extends MitemsModElements.ModElement {
	@ObjectHolder("mitems:overpoweredsword")
	public static final Item block = null;
	public OverpoweredswordItem(MitemsModElements instance) {
		super(instance, 51);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 100;
			}

			public float getEfficiency() {
				return 4f;
			}

			public float getAttackDamage() {
				return 998f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 3, -3f, new Item.Properties().group(MItemsmiscItemGroup.tab)) {
		}.setRegistryName("overpoweredsword"));
	}
}
