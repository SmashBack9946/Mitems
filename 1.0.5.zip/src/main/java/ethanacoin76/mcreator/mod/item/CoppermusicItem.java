
package ethanacoin76.mcreator.mod.item;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.Item;

import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import ethanacoin76.mcreator.mod.MitemsModElements;

@MitemsModElements.ModElement.Tag
public class CoppermusicItem extends MitemsModElements.ModElement {
	@ObjectHolder("mitems:coppermusic")
	public static final Item block = null;
	public CoppermusicItem(MitemsModElements instance) {
		super(instance, 37);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, (net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.bee.loop")),
					new Item.Properties().group(MitemsItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("coppermusic");
		}
	}
}
